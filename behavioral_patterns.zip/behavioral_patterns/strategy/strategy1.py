class Strategy1:
    def execute(self):
        print("Executing Strategy 1...")
