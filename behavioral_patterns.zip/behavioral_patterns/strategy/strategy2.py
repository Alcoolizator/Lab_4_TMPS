class Strategy2:
    def execute(self):
        print("Executing Strategy 2...")