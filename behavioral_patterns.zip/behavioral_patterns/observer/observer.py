class Observer:
    def update(self, message):
        pass
