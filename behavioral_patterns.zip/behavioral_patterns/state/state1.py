class State1:
    def perform_action(self):
        print("Performing Action in State 1...")