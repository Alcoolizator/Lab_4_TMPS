class State2:
    def perform_action(self):
        print("Performing Action in State 2...")